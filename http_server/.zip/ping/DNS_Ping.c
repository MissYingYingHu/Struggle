//由域名解析IP
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <netinet/ip_icmp.h>
#include <sys/time.h>

#define BUF_SIZE 1024
#define LEN 56
int sendnum = 0;
int revcnum = 0;
char sendpack[BUF_SIZE];
char recvpack[BUF_SIZE];
long diftime(const struct timeval*end,const struct timeval* begin)
{
  int ret = (end->tv_sec - begin->tv_sec)*1000 +
    (end->tv_usec - begin->tv_usec)/1000;
    
  return ret;
}
int pack(int num,pid_t pid)
{
   struct icmp* p = (struct icmp*)sendpack;
   p->icmp_type = ICMP_ECHOREPLY;
   p->icmp_code = 0;
   p->icmp_cksum = 0;
   p->icmp_seq = num;
   p->icmp_id = pid;
   struct timeval val;
   gettimeofday(&val,NULL);
   memcpy((void*)p->icmp_data,(void*)&val,sizeof(val));
   p->icmp_cksum = chksum((unsigned short*)sendpacket,LEN+8);
   return LEN+8;
}
void sendpacket(int fd,pid_t pid,struct sockaddr_in ad)
{
    sendnum++;
   int size = pack(sendnum,pid);
   sendto(fd,sendpack);
}
void unpack(char revepack,int len,pid_t pid)
{
    struct ip* pip = (struct ip* )buf;
    struct icmp* picmp = (struct icmp*)(pip->ip_hl<<2);
    if(picmp->icmp_id == pid)
    {
        printf("")
    }

}
void recvpacket(int fd,pid_t pid)
{
    struct sockaddr_in from;
    from.sin_addr = AF_INET;
    socklen_t len = sizeof(from);
    mempcy(revepack,0x00,sizeof(recvpack));
    int r =0;
    r = recvfrom(fd,recvpack,BUF_SIZE,0,(sockaddr*)&from,&len);
    unpack(recvpack,r,pid);
}

unsigned short chksum(unsigned short* addr,int len)
{
    unsigned int ret = 0;
    while(len > 1)
    {
        ret += *addr++;
        len -= 2;
    }
    if(len == 1)
    {
        ret += *(unsigned char*)addr;
    }

    ret = (ret >> 16) + (ret & 0xffff);
    ret += (ret >> 16);
    return (unsigned short)~ret;
}
int main(int argc,char* argv[])
o
    if(argc != 2)
    {
        return 1;
    }
    struct in_addr addr;
    if((addr.s_addr = inet_addr(argv[1])) == INADDR_NONE)
    {
        struct hostent* pent = gethostbyname(argv[1]);
        if(pent == NULL)
        {
            perror("gethostbyname");
            exit(1);
        }
        memcpy(&addr,(char*)pent->h_addr,pent->h_length);
    }
    int fd = socket(AF_INET,SOCK_RAW,IPPROTO_ICMP);
    if(fd < 0)
    {
        perror("socket");
        exit(1);
    }
    struct sockaddr_in ad;
    ad.sin_family = AF_INET;
    ad.sin_addr = addr;
    pid_t pid = getpid();
    while(1)
    {
        sendpacket(fd,pid,ad);
        recvpacket(fd,pid);
        sleep(1);
    }
    printf("%s\n",inet_ntoa(addr));
    return 0;
}
