#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/time.h>


long diftime(const struct timeval*end,const struct timeval* begin)
{
  int ret = (end->tv_sec - begin->tv_sec)*1000 +
    (end->tv_usec - begin->tv_usec)/1000;
    
  return ret;
}
int main()
{
  struct timeval begin;
  gettimeofday(&begin,NULL);
  sleep(1);
  struct timeval end;
  gettimeofday(&end,NULL);

//  int ret = (end.tv_sec - begin.tv_sec)*1000 +
//    (end.tv_usec - begin.tv_usec)/1000;

  long ret = diftime(&end,&begin);
  printf("%lu\n",ret);
  return 0;
}
