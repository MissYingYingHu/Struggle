#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

int main()
{
    int fd = socket(AF_INET,SOCK_RAW,IPPROTO_ICMP); 
    if(fd < 0)
    {
        perror("socket");
        exit(1);
    }

    int opt = 1;
    setsockopt(fd,IPPROTO_IP,IP_HDRINCL,&opt,sizeof(opt));

    char buf[1500] = {0};
    while(1)
    {
        ssize_t read_size = read(fd,buf,sizeof(buf));
        if(read_size < 0)
        {
            perror("read");
            exit(1);
        }
        struct iph
    }
    return 0;
}
